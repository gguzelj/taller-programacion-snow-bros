class ObjectHandler{
private:

public:
	addBody();
};
