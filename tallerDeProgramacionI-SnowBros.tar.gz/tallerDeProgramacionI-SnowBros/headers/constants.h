#ifndef CONSTANTS_H_
#define CONSTANTS_H_
/*####### Valores por default de la ventana ####### */

const int ALTO_PX = 720;
const int ANCHO_PX = 1024;
const int PX_TO_MTR = 40;

#endif /* CONSTANTS_H_ */
