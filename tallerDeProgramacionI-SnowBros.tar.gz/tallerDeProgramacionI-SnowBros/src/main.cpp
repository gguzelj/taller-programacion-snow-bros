#include "../headers/ventanaGrafica.h"
#include "../headers/ObjectFactory.h"
#include "../headers/Drawer.h"
#include "../headers/JsonParser.h"

int main(int argc,char* argv[]){

        JsonParser *parser = new JsonParser();
        parser->test();

//  Aca hay que pedirle los parametros al parser
//  Ej: VentanaGrafica* window = new VentanaGrafica(parser->getAlto_px(),parser->getAncho_px(),parser->getImage());

        //Inicializar la ventana
        VentanaGrafica* window = new VentanaGrafica();
        Drawer* drawer = window;

        //Inicializamos el ObjectFactory
        ObjectFactory* objectFactory = new ObjectFactory();

        //Inicializamos el world del Box2D
        b2World* world = objectFactory->crearb2World();

        //Creamos las plataformas
        objectFactory->createPlatforms(world);

        //Parametros del step
        float32 timeStep = 1.0f / 60.0f;
        int32 velocityIterations = 8;
        int32 positionIterations = 2;

        // Game loop.
        SDL_Event e;
        bool quit = false;
        while (!quit){
                //Event Polling
                while (SDL_PollEvent(&e)){
                        if (e.type == SDL_QUIT){
                                quit = true;
                        }
                        if (e.type == SDL_KEYDOWN){
                                switch (e.key.keysym.sym){
                                        case SDLK_ESCAPE:
                                                quit = true;
                                                break;
                                        default:
                                                break;
                                }
                        }
                }
                // Instruct the world to perform a single step of simulation.
                // It is generally best to keep the time step and iterations fixed.
                world->Step(timeStep, velocityIterations, positionIterations);

                drawer->clearScenary();
                drawer->drawBackground();
                drawer->drawScenary(world);
                drawer->presentScenary();
                SDL_Delay(10);
        }

        delete drawer;
        delete world;

        return 0;
}
