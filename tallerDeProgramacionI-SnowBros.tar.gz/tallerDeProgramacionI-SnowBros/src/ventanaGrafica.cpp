#include "../headers/ventanaGrafica.h"

//Cuando se tenga el parser, sacar el res_path
#include "../headers/res_path.h"

VentanaGrafica::VentanaGrafica(){
        this->alto_px = ALTO_PX;
        this->ancho_px = ANCHO_PX;
        this->imagePath = getResourcePath("chapelco.jpg");
        this->window = nullptr;
        this->renderer = nullptr;
        this-> image = nullptr;

        this->inicializarSDL();
}

VentanaGrafica::VentanaGrafica(int alto_px ,int ancho_px , string imagePath){
        this->alto_px = alto_px;
        this->ancho_px = ancho_px;
        this->imagePath = imagePath;
        this->window = nullptr;
        this->renderer = nullptr;
        this-> image = nullptr;

        this->inicializarSDL();
}

void VentanaGrafica::clearScenary(){
        SDL_RenderClear(this->renderer);
}

void VentanaGrafica::drawBackground(){
        //Drawing the texture
        SDL_RenderCopy(this->renderer,this->image, NULL, NULL); //Se pasa NULL para que ocupe todo el renderer
}

void VentanaGrafica::drawScenary(b2World* world){
        for(b2Body* body = world->GetBodyList(); body; body = body->GetNext()){
                this->drawStaticBody(body);
        }
}

//Dibuja un cuerpo estatico
void VentanaGrafica::drawStaticBody(b2Body* body){
        SDL_SetRenderDrawColor(this->renderer, 50, 50, 50, 255);
        int ox = ((int)ANCHO_PX)/2;
        int oy = ((int)ALTO_PX)/2;
        //http://box2d.org/forum/viewtopic.php?f=3&t=1933
        for( b2Fixture *fixture = body->GetFixtureList(); fixture; fixture = fixture->GetNext() ){
                if( fixture->GetType() == b2Shape::e_polygon ){
                        b2PolygonShape *poly = (b2PolygonShape*)fixture->GetShape();

                        const int count = poly->GetVertexCount();

                        for( int i = 0; i < count; i++ ){
                                int ind0 = (i + 1) % count ;
                                b2Vec2 p0 = body->GetWorldPoint(  poly->GetVertex( ind0 ) );
                                b2Vec2 p1 = body->GetWorldPoint(  poly->GetVertex(i) );

                                SDL_RenderDrawLine(this->renderer, PX_TO_MTR * p0.x + ox,
                                								   -PX_TO_MTR * p0.y + oy,
                                								   PX_TO_MTR * p1.x + ox,
                                								   -PX_TO_MTR * p1.y + oy);
                        }
                }
        }
}

void VentanaGrafica::presentScenary(){
        SDL_RenderPresent(this->renderer);
}

//Aca hay que ver temas referentes a errores.
void VentanaGrafica::inicializarSDL(){
        //Start up SDL and make sure it went ok
        if (SDL_Init(SDL_INIT_EVERYTHING) != 0){
                logSDLError(std::cout, "SDL_Init");
                throw;
        }

        //Opening a window
        this->window = SDL_CreateWindow("Snow Bros", SDL_WINDOWPOS_CENTERED , SDL_WINDOWPOS_CENTERED, this->ancho_px, this->alto_px, SDL_WINDOW_SHOWN);
        if (this->window == nullptr){
                logSDLError(std::cout, "CreateWindow");
                IMG_Quit();
                SDL_Quit();
                throw;
        }

        //Creating a renderer
        renderer = SDL_CreateRenderer(this->window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
        if (this->renderer == nullptr){
                SDL_DestroyWindow(this->window);
                logSDLError(std::cout, "CreateRenderer");
                IMG_Quit();
                SDL_Quit();
                throw;
        }

        //Loading the image
        this->image = this->loadTexture(this->imagePath, renderer);
        if (this->image == nullptr){
                SDL_DestroyTexture(this->image);
                SDL_DestroyRenderer(this->renderer);
                SDL_DestroyWindow(this->window);
                IMG_Quit();
                SDL_Quit();
                throw;
        }
}

SDL_Texture* VentanaGrafica::loadTexture(const std::string &file, SDL_Renderer *ren){
        SDL_Texture *texture = IMG_LoadTexture(ren, file.c_str());
        if (texture == nullptr){
                logSDLError(std::cout, "LoadTexture");
        }
        return texture;
}

void VentanaGrafica::logSDLError(std::ostream &os, const std::string &msg){
        os << msg << " error: " << SDL_GetError() << std::endl;
}

VentanaGrafica::~VentanaGrafica(){
        //Cleaning up
        SDL_DestroyTexture(image);
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_Quit();
        IMG_Quit();
}
